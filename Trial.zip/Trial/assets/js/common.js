$(document).ready(function(){
    // Add smooth scrolling to all links
    $('a').on('click touchend', function(event) {
        event.preventDefault();
        var link = $(this).attr('href');
        if($(this).attr('target') == '_blank'){
            window.open(link,'_blank'); // opens in new window as requested
        }else{
            window.location.href = link;
        }


        return false; // prevent anchor click
    });

    $("#toggle").click(function(e){
        if($("#toggle").prop('checked') == true){
            $("body").css("overflow","hidden");
        }
        else{
            $("body").css("overflow","auto");
        }
    })

    $("#page_content").css("height", $(window).height() - $("#header").height() - $("#footer").height() + "px");
});